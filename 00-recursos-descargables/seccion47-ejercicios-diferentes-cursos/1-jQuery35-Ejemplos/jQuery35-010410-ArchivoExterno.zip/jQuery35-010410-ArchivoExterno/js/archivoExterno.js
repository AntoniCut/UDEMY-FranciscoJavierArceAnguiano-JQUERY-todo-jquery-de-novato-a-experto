$(document).ready(function(){
  $("#foto").click(function(){
    $("#foto").hide();
  });
});