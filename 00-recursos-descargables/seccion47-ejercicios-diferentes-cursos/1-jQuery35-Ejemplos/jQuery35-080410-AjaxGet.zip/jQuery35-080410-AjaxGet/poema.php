<?php
$poema = rand(0,2);
if($poema==0){
	print "<h2>POEMA POPULAR</h2>";
	print "<p>EN EL AGUA CLARA</p>";
	print "<p>QUE BROTA EN LA FUENTE</p>";
	print "<p>UN LINDO PESCADO</p>";
	print "<p>SALE DE REPENTE</p>";
	print "<p>LINDO PESCADITO</p>";
	print "<p>NO QUIERES VENIR</p>";
	print "<p>A JUGAR CON MI ARO</p>";
	print "<p>VAMOS AL JARDIN</p>";
	print "<p>MI MAMA ME DIJO</p>";
	print "<p>PORQUE SI TE SALES</p>";
	print "<p>TE VAS A MORIR!</p>";
	print "<h3>Poema anonimo</p>";
} else if($poema==1){
	print "<h2>REDONDILLAS</h2>";
	print "<p>HOMBRES NECIOS QUE ACUSAIS</p>";
	print "<p>A LA MUJER, SIN RAZON</p>";
	print "<p>SIN VER QUE SOY LA OCASION</p>";
	print "<p>DE LO MISMO QUE CULPAIS.</p>";
	print "<BR>";
	print "<p>SI CON ANSIA SIN IGUAL</p>";
	print "<p>SOLICITAIS SU DESDEN</p>";
	print "<p>POR QUE QUEREIS QUE OBREN BIEN</p>";
	print "<p>SI LAS INSITAIS AL MAL?</p>";
	print "<h3>SOR JUANA INES DE LA CRUZ</p>";
} else if($poema==2){
	print "<h2>NOCTURNO A ROSARIO</h2>";
	print "<p>PUES BIEN, YO NECESITO</p>";
	print "<p>DECIRTE QUE TE ADORO</p>";
	print "<p>DECIRTE QUE TE QUIERO</p>";
	print "<p>CON TODO EL CORAZON.</p>";
	print "<BR>";
	print "<p>QUE ES MUCHO LO QUE SUFRO</p>";
	print "<p>QUE ES MUCHO LO QUE LLORO,</p>";
	print "<p>QUE YA NO PUEDO  TANTO</p>";
	print "<p>CON TODO EL CORAZON</p>";
	print "<h3>MANUEL ACU&Ntilde;A</p>";
}
?>